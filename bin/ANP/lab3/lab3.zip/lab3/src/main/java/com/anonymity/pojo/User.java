package com.anonymity.pojo;

public class User {
    private String username;
    private String sex;
    private String Zodiac;

    public User(String username, String sex, String zodiac) {
        this.username = username;
        this.sex = sex;
        Zodiac = zodiac;
    }

    public User() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getZodiac() {
        return Zodiac;
    }

    public void setZodiac(String zodiac) {
        Zodiac = zodiac;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", sex='" + sex + '\'' +
                ", Zodiac='" + Zodiac + '\'' +
                '}';
    }
}
