package com.anonymity.Controller;

import com.anonymity.pojo.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpSession;

@Controller
public class HoroscopeServlet {
    //如果请求路径和Value值相同，则执行该处理方法
    @RequestMapping("/Horoscope")
    public String Horoscope(){
        return "Horoscope";
    }
    @RequestMapping("/TS")
    public String Print(HttpSession session, User user){
        //获取参数
        String sex= user.getSex();
        String name= user.getUsername();
        //zodiac变为int类型
        String zodiac = user.getZodiac();
        int zodiacInt = Integer.parseInt(zodiac);
        System.out.println(zodiacInt);

        //将表格数据存入session
        session.setAttribute("username",name);

        //判断星座，写出对应的运势
        if (zodiacInt <= 6 && sex.equals("Male")) {
            session.setAttribute("horoscope", "You will have a long life");
        }else if (zodiacInt > 6 || user.getSex().equals("Male")) {
            session.setAttribute("horoscope", "You will have a rich life.");
        }else if (zodiacInt <= 6 && sex.equals("Female")) {
            session.setAttribute("horoscope", "You will find a tall handsome stranger.");
        }else if (zodiacInt > 6 || user.getSex().equals("Female")) {
            session.setAttribute("horoscope", "You will have six children.");
        }
        //将逻辑视图返回
        return "success";
    }

}
/**
1. Java，使用Node.js的JavaScript，

        2. 首先创建JavaScript的相关函数，调用DOM树结构将HTML中的数据进行选择，之后书写函数进行判断

        3.

        如果是没有输入姓名：Please input your name!，页面不会跳转

        如果是没有输入姓名：Please input your name correctly!，页面不会跳转

        如果是没有输入姓名：Please select your gender，页面不会跳转

        4. 不会

        5. 将HTML的name改为college username ，之后JavaScript中的check函数的正则表达式按照下述进行修改：

        >1. Is not empty and,
        >2. Starts with the sequence “jp2019” and
        >3. Ends with a digit.

**/
